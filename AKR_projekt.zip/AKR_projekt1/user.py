from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Signature import PKCS1_v1_5
from Crypto import Random
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding

class User: # třída uživatelů systému
    def __init__(self, name):  # inicializace nové instance uživatele a generování RSA klíče o délce 2048 bitů
        random = Random.new().read
        self.name = name
        self.private_key = RSA.generate(2048, random)
        self.public_key = self.private_key.publickey()
        self.sym_key = None  # Symetrický klíč
        self.inbox = []
        self.messages = []

    def verify_certificate(self, ca_public_key, signature): # ověření certifikátu CA
        verifier = PKCS1_v1_5.new(ca_public_key)
        digest = SHA256.new(self.public_key.export_key())
        if verifier.verify(digest, signature):
            return True
        else:
            return False

    def generate_symmetric_key(self, password):
        # odvození symetrického klíče z hesla pomocí PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'salt_123',  # pevně daná sůl
            iterations=100000,
            backend=default_backend()
        ) # používáme SHA-256 hash, délku klíče 32 bajtů, pevně danou sůl a 100 000 iterací
        self.sym_key = kdf.derive(password.encode())

    def encrypt_message(self, message):
        # šifrování zprávy symetrickým klíčem pomocí AES v režimu CBC
        padder = padding.PKCS7(128).padder() # vytváření paddingu
        padded_data = padder.update(message.encode()) + padder.finalize() #přidání paddingu ke zprávě

        iv = Random.new().read(AES.block_size)  # generování náhodný inicializační vektor délky 16 bajtů
        cipher = AES.new(self.sym_key, AES.MODE_CBC, iv)
        encrypted_message = iv + cipher.encrypt(padded_data) # šifrování zprávy s IV a sym.klíčem
        return encrypted_message

    def decrypt_message(self, encrypted_message):
        # dešifrování zprávy symetrickým klíčem
        iv = encrypted_message[:AES.block_size] # získáme IV ze zašifrované zprávy
        cipher = AES.new(self.sym_key, AES.MODE_CBC, iv) # inicializace šifry s CBC režimem a IV
        decrypted_padded_data = cipher.decrypt(encrypted_message[AES.block_size:]) # dešifrujeme zprávu

        unpadder = padding.PKCS7(128).unpadder() # inicializace unpadderu
        decrypted_message = unpadder.update(decrypted_padded_data) + unpadder.finalize()
        return decrypted_message.decode() # dekodování dešifrované zprávy a návrat jako řetězec