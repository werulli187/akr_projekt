from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Signature import PKCS1_v1_5
from Crypto import Random

class CertificateAuthority:
    def __init__(self): # vygenerování nového RSA privátního a veřejného klíče o délce 2048 bitů pro CA
        random = Random.new().read
        self.name = "Certificate Authority"
        self.private_key = RSA.generate(2048, random) #privátní a veřejný RSA klíč o délce 2048 bitů.
        self.public_key = self.private_key.publickey()

    def sign_user_key(self, user): # podepsání vK uživatele pomocí pK CA
        #k tomu použijeme PKCS#1 v1.5 padding a SHA-256 hash
        signer = PKCS1_v1_5.new(self.private_key)
        digest = SHA256.new(user.public_key.export_key())
        signature = signer.sign(digest)
        return signature

    def verify_user_key(self, user, signature): # ověření podepsaného vK uživatele pomocí vK CA
        verifier = PKCS1_v1_5.new(self.public_key)
        digest = SHA256.new(user.public_key.export_key())
        if verifier.verify(digest, signature):
            return True
        else:
            return False