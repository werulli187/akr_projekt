from certificate_authority import CertificateAuthority
from user import User

# vytvoření instance certifikační autority
ca = CertificateAuthority()

# vytvoření uživatelů
Bob = User("Bob")
Alice = User("Alice")

# podepsání veřejných klíčů uživatelů certifikační autoritou a uložení podpisů
bob_signature = ca.sign_user_key(Bob)
alice_signature = ca.sign_user_key(Alice)

# ověření veřejných klíčů uživatelů pomocí CA
is_bob_key_valid = ca.verify_user_key(Bob, bob_signature)
if is_bob_key_valid:
    print("Veřejný klíč uživatele Bob byl úspěšně ověřen.")
else:
    print("Veřejný klíč uživatele Bob není platný.")

is_alice_key_valid = ca.verify_user_key(Alice, alice_signature)
if is_alice_key_valid:
    print("Veřejný klíč uživatele Alice byl úspěšně ověřen.")
else:
    print("Veřejný klíč uživatele Alice není platný.")

# Bob vygeneruje symetrický klíč a pošle ho Alici
password = "secret_password"  # nejdříve se určí heslo k odvození symetrického klíče
Bob.generate_symmetric_key(password) #dále se použije k vygenerování symetrického klíče pomocí funkce odvozování klíče PBKDF2
Alice.sym_key = Bob.sym_key #nastavení klíče vygenerovaným Bobem pro Alici

# Alice již může použít sdílený symetrický klíč pro šifrování

# simulace šifrované komunikace:
alice_message = "Ahoj Bobe, jak se máš?"
# zpráva je šifrována pomocí symetrického klíče
encrypted_message = Alice.encrypt_message(alice_message)
Bob.inbox.append(encrypted_message)

bob_message = "Ahoj Alice, jsem v pořádku. Jak se máš ty?"
#zpráva je šifrována pomocí sdíleného symetrického klíče, poté uložena do Alicina inboxu
encrypted_message = Bob.encrypt_message(bob_message)
Alice.inbox.append(encrypted_message)

# dešifrování a zobrazení zpráv v inboxu uživatele Boba
for encrypted_message in Bob.inbox: #pro každou šifrovanou zprávu v Bobově inboxu se provede dešifrování pomocí symetrického klíče
    decrypted_message = Bob.decrypt_message(encrypted_message)
    print("Bob přijal zprávu:", decrypted_message) #pro každou dešifrovanou zprávu se vypíše obsah zprávy spolu s informací, že Bob tuto zprávu přijal

# dešifrování a zobrazení zpráv v inboxu uživatele Alice
for encrypted_message in Alice.inbox:
    decrypted_message = Alice.decrypt_message(encrypted_message)
    print("Alice přijala zprávu:", decrypted_message)