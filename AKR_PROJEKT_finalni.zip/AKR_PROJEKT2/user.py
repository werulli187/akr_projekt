from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Cipher import DES
from Crypto.Signature import PKCS1_v1_5
from Crypto import Random
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding

# třída uživatelů systému:
class User:
    def __init__(self, name):  # inicializace nové instance uživatele a generování RSA klíče o délce 2048 bitů
        self.name = name
        self.private_key = None
        self.public_key = None
        self.sym_key = None  # symetrický klíč
        self.inbox = []

    #generování rsa klíče:
    def generate_rsa_keys(self, rsa_key_length):
        random = Random.new().read
        self.private_key = RSA.generate(rsa_key_length, random)
        self.public_key = self.private_key.publickey()

    # ověření certifikátu CA:
    def verify_certificate(self, ca_public_key, signature, hash_algorithm=SHA256, padding_algorithm=PKCS1_v1_5):
        verifier = padding_algorithm.new(ca_public_key)
        digest = hash_algorithm.new(self.public_key.export_key())
        if verifier.verify(digest, signature):
            return True
        else:
            return False

    #generování symetrického klíče
    # používáme SHA-256 hash, délku klíče 32 bajtů, pevně danou sůl a 100 000 iterací
    def generate_symmetric_key(self, password,hash_algorithm=hashes.SHA256, iterations=100000, salt=b'salt_123', length=32):
        # odvození symetrického klíče z hesla pomocí PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hash_algorithm(),
            length=length,
            salt=salt,
            iterations=iterations,
            backend=default_backend()
        )
        self.sym_key = kdf.derive(password.encode())

    #šifrování zprávy
    def encrypt_message(self, message, sym_algorithm=AES, mode=AES.MODE_CBC, padding_length=128):
        # šifrování zprávy symetrickým klíčem pomocí AES v režimu CBC
        padder = padding.PKCS7(padding_length).padder() # vytváření paddingu
        padded_data = padder.update(message.encode()) + padder.finalize() #přidání paddingu ke zprávě

        iv = Random.new().read(sym_algorithm.block_size)  # generování náhodný inicializační vektor délky 16 bajtů
        cipher = sym_algorithm.new(self.sym_key, mode, iv)
        encrypted_message = iv + cipher.encrypt(padded_data) # šifrování zprávy s IV a sym.klíčem
        return encrypted_message

    #dešifrování zprávy
    def decrypt_message(self, encrypted_message, sym_algorithm=AES, mode=AES.MODE_CBC):
        # dešifrování zprávy symetrickým klíčem
        iv = encrypted_message[:sym_algorithm.block_size] # získáme IV ze zašifrované zprávy
        cipher = sym_algorithm.new(self.sym_key, mode, iv) # inicializace šifry s CBC režimem a IV
        decrypted_padded_data = cipher.decrypt(encrypted_message[sym_algorithm.block_size:]) # dešifrujeme zprávu

        unpadder = padding.PKCS7(128).unpadder() # inicializace unpadderu
        decrypted_message = unpadder.update(decrypted_padded_data) + unpadder.finalize()
        return decrypted_message.decode() # dekodování dešifrované zprávy a návrat jako řetězec