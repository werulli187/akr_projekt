from certificate_authority import CertificateAuthority
from user import User
from Crypto.Cipher import AES
from Crypto.Cipher import DES
from Crypto.Hash import SHA256
from Crypto.Hash import SHA512
from Crypto.Signature import PKCS1_v1_5
from cryptography.hazmat.primitives import padding

# uživatel zadává požadované parametry
rsa_key_length = int(input("Zadejte délku RSA klíče pro certifikační autoritu: "))
ca = CertificateAuthority(rsa_key_length=rsa_key_length)

user_key_length = int(input("Zadejte délku RSA klíče pro uživatele: "))
user = User("Bob")
user.generate_rsa_keys(rsa_key_length=user_key_length)

symmetric_key_length = int(input("Zadejte délku symetrického klíče: "))
password = input("Zadejte heslo pro odvození symetrického klíče: ")
user.generate_symmetric_key(password, length=symmetric_key_length)

# volba symetrického šifrovacího algoritmu
sym_algorithm_choice = input("Zvolte symetrický šifrovací algoritmus (např. AES, DES) (výchozí AES): ")
if sym_algorithm_choice.lower() == "aes":
    sym_algorithm = AES
    # volba módu symetrického šifrování pro AES
    mode_choice = input("Zvolte mód symetrického šifrování pro AES (např. CBC, ECB) (výchozí CBC): ")
    if mode_choice.lower() == "cbc":
        mode = AES.MODE_CBC
    elif mode_choice.lower() == "ecb":
        mode = AES.MODE_ECB
    else:
        mode = AES.MODE_CBC  # výchozí mód pro AES
elif sym_algorithm_choice.lower() == "des":
    sym_algorithm = DES
    mode = DES.MODE_ECB  # DES nepodporuje různé módy jako AES, tudíž jedna volba
else:
    sym_algorithm = AES  # výchozí volba pro neznámý algoritmus
    mode = AES.MODE_CBC  # výchozí mód pro AES

# volba hashovacího algoritmu
hash_algorithm_choice = input("Zvolte hashovací algoritmus (např. SHA256, SHA512) (výchozí nastavení SHA256): ")
if hash_algorithm_choice.lower() == "sha256":
    hash_algorithm = SHA256
elif hash_algorithm_choice.lower() == "sha512":
    hash_algorithm = SHA512
else:
    hash_algorithm = SHA256

# volba padding algoritmu
padding_algorithm_choice = input("Zvolte padding algoritmus (např. PKCS7, PKCS5, ...) (výchozí nastavení PKCS7): ")
if padding_algorithm_choice.lower() == "pkcs7":
    padding_algorithm = padding.PKCS7
else:
    padding_algorithm = padding.PKCS7  # defaultní volba

# podepsání veřejného klíče uživatele certifikační autoritou a uložení podpisu
bob_signature = ca.sign_user_key(user)

# ověření veřejného klíče uživatele pomocí CA
is_key_valid = ca.verify_user_key(user, bob_signature)
if is_key_valid:
    print("Veřejný klíč uživatele byl úspěšně ověřen.")
else:
    print("Veřejný klíč uživatele není platný.")

# Alice již může použít sdílený symetrický klíč pro šifrování

# vytvoření instance objektu Alice
Alice = User("Alice")
Alice.generate_rsa_keys(rsa_key_length=user_key_length)
Alice.generate_symmetric_key(password, length=symmetric_key_length)

#vyvtvoření instance objektu Bob
Bob = User("Bob")
Bob.generate_rsa_keys(rsa_key_length=user_key_length)
Bob.generate_symmetric_key(password, length=symmetric_key_length)

# simulace šifrované komunikace:
alice_message = "Ahoj Bobe, jak se máš?"
# zpráva je šifrována pomocí symetrického klíče
encrypted_message = Alice.encrypt_message(alice_message, sym_algorithm=sym_algorithm, padding_length=128)
Bob.inbox.append(encrypted_message)

bob_message = "Ahoj Alice, mám se dobře. Jak se máš ty?"
# zpráva je šifrována pomocí sdíleného symetrického klíče, poté uložena do Alicina inboxu
encrypted_message = Bob.encrypt_message(bob_message, sym_algorithm=sym_algorithm, padding_length=128)
Alice.inbox.append(encrypted_message)

# dešifrování a zobrazení zpráv v inboxu uživatele Boba
for encrypted_message in Bob.inbox:  # pro každou šifrovanou zprávu v Bobově inboxu se provede dešifrování pomocí symetrického klíče
    decrypted_message = Bob.decrypt_message(encrypted_message, sym_algorithm=sym_algorithm)
    print("Bob přijal zprávu:", decrypted_message)  # pro každou dešifrovanou zprávu se vypíše obsah zprávy spolu s informací, že Bob tuto zprávu přijal

# dešifrování a zobrazení zpráv v inboxu uživatele Alice
for encrypted_message in Alice.inbox:
    decrypted_message = Alice.decrypt_message(encrypted_message, sym_algorithm=sym_algorithm)
    print("Alice přijala zprávu:", decrypted_message)