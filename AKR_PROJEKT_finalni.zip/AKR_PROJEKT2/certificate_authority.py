#importování kryptografických knihoven
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Signature import PKCS1_v1_5
from Crypto import Random

class CertificateAuthority:
    # vygenerování nového RSA privátního a veřejného klíče:
    def __init__(self, rsa_key_length=2048): #možnost nastavení délky klíče
        random = Random.new().read
        self.name = "Certificate Authority"
        self.private_key = RSA.generate(rsa_key_length, random) #privátní a veřejný RSA klíč o zadané délce
        self.public_key = self.private_key.publickey()

    # podepsání vK uživatele pomocí pK CA:
    def sign_user_key(self, user, hash_algorithm=SHA256, padding_algorithm=PKCS1_v1_5): # volby padding a hashovacího algoritmu
        #k tomu použijeme PKCS#1 v1.5 padding a SHA-256 hash
        signer = padding_algorithm.new(self.private_key)
        digest = hash_algorithm.new(user.public_key.export_key())
        signature = signer.sign(digest)
        return signature

    # ověření podepsaného vK uživatele pomocí vK CA:
    def verify_user_key(self, user, signature, hash_algorithm=SHA256, padding_algorithm=PKCS1_v1_5): # volby padding a hashovacího algoritmu
        verifier = padding_algorithm.new(self.public_key)
        digest = hash_algorithm.new(user.public_key.export_key())
        if verifier.verify(digest, signature):
            return True
        else:
            return False